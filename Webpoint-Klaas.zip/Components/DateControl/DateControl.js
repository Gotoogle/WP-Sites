// DateControl.js
// --------------

// Implements JavaScript interactivity - changing sequence of control fields
// This file must be included in the page whereever a date control needs to react
// to such changes


// DateSequenceChange callback function
function DateSequenceChanged(event, data)
{
	if (!event.param) return;
  
  // Get the new sequence and compare to current sequence; don't update if the same
  var controlName = event.param[0],
	    Sequence = event.param[1].toUpperCase(),
      curSequence = eval(data + "Sequence");
  if (controlName.toUpperCase() != "ADDRESS" || Sequence == curSequence) return;               // React only on general address control changes

  // Get the field objects and save the current selection
  var DayControl = findObject(data + "Day"), MonthControl = findObject(data + "Month"), YearControl = findObject(data + "Year"),
      dayList = findObject(data + "DayList"), monthList = findObject(data + "MonthList"), yearList = findObject(data + "YearList"),
      cloneDay = DayControl.cloneNode(true), cloneMonth = MonthControl.cloneNode(true), cloneYear = YearControl.cloneNode(true),
      parentNode = DayControl.parentNode, i,
      daySel = dayList ? dayList.selectedIndex : -1, monthSel = monthList ? monthList.selectedIndex : -1, yearSel = yearList ? yearList.selectedIndex : -1;

  if (!cloneDay || !cloneMonth || !cloneYear) return;

  // Delete all elements...
  while (parentNode && parentNode.firstChild) { parentNode.removeChild(parentNode.firstChild); }

  // ...and insert their clones at the new position
  for (i = 0; i < Sequence.length; i++) {
    if (Sequence.charAt(i) == 'D') parentNode.appendChild(cloneDay);
		else if (Sequence.charAt(i) == 'M') parentNode.appendChild(cloneMonth);
    else if (Sequence.charAt(i) == 'Y') parentNode.appendChild(cloneYear);
	}

  // Restore selection (because IE doesn't save it while cloning)
  dayList = findObject(data + "DayList");
  monthList = findObject(data + "MonthList");
  yearList = findObject(data + "YearList");
  if (dayList) dayList.selectedIndex = daySel;
  if (monthList) monthList.selectedIndex = monthSel;
  if (yearList) yearList.selectedIndex = yearSel;
  
  // Update the current sequence
  var f = new Function("Sequence", data + "Sequence = Sequence");
  f(Sequence);
}