// AddressControl.js
// -----------------
//
// Functions for the javascripted interactivity of the Address Control


// Finds out if the country is selectable or not
function HasCountrySelection(name)
{
	var countries = findObject(name.toLowerCase() + "_country_sel");
	return (countries && countries.options) ? true : false;
}

// Same for cities
function HasCitySelection(name)
{
	var cities = findObject(name.toLowerCase() + "_city_sel");
	return (cities && cities.options) ? true : false;
}

// Gets the currently selected country code
// It's pre-selected in case country selection is disabled, otherwise it's taken from the country combo box.
function GetCountryCode(name)
{
  if (NoCountrySelection) return DefaultCountryCode;
  var countries = findObject(name + "_country_sel");
	return countries.options[countries.options.selectedIndex].value.toUpperCase();
}

// Finds a state in the global list
function GetStateIndex(cc, State)
{
	// For countries without states
	if (State == -2) return 0;

	// Lookup state index
	try {
		for (var i = 0; i < Places[cc].States.length; i++)
		  if (Places[cc].States[i].Name == State) return i;
	} catch(e) {
		return -1;
	}
	return -1;
}

// Prefixes a caption with "Other" if told so
function PrefixCaption(Caption, Text, DoIt)
{
	var S = Text;
	if (DoIt) S = Prefix + S;
	Caption.innerHTML = S;
}

// Fill function for states
function StateFillFunc(Control, CountryCode, State)
{
	var Count = Control.options.length;
	try {
	  for (var i = 0; i < Places[CountryCode].States.length; i++)
		  Control.options[Count++] = new Option(Places[CountryCode].States[i].Name, Places[CountryCode].States[i].Name);
	  if (Places[CountryCode].States[0].Name.toUpperCase() == "DEFAULT") return -2;
	} catch(e) {
		return DefaultHasStates ? -1 : -2;
	}
	return Count;
}

// Fill function for cities
function CityFillFunc(Control, CountryCode, State)
{
	var Count = Control.options.length;
	try {
    for (var i = 0; i < Places[CountryCode].States[State].Cities.length; i++)
		  Control.options[Count++] = new Option(Places[CountryCode].States[State].Cities[i], Places[CountryCode].States[State].Cities[i]);
	} catch(e) {
		return -1;
	}
	return Count;
}

// Fills in a selection box with entries; this will automatically show or hide the necessary controls
function FillSelectionItems(Control, FillFunc, CountryCode, State, SelectionRow, InputRow, ToSelect)
{
	// Empty the control
	Control.options.length = 0;
	Control.options.selectedIndex = -1;

	// Fill the Control by calling the filling function
	Control.options[0] = new Option("Please select", 0);
  Control.options[1] = new Option("---------------------", 0);
  var Count = FillFunc(Control, CountryCode, State);
  if (Count < 0) {
    if (Count == -1) Control.options.length = 0;
		Control.options.selectedIndex = -1;
		showElements(SelectionRow, false);
		showElements(InputRow, (Count == -1));
  } else {
		Control.options[Count] = new Option("Other", -1);
		showElements(SelectionRow, true);

		// When initialising, try to select the user input
		if (Initial && ToSelect.value != "") {
			if (selectByTextIgnoreCase(Control, ToSelect.value) == -1) {
				selectByValue(Control, -1);
    		showElements(InputRow, true);
			} else {
				showElements(InputRow, false);
				ToSelect.value = "";
			}
		} else {
      showElements(InputRow, false);
			ToSelect.value = "";
		}
	}
}

// Applies the country dependent display options to the page
function CountryOptions(CountryCode, name)
{
  // Try to find the currently selected country determining various options for the control; if that's not possible
  // or the country does not specify options, take the default country options object
  var country = Places[CountryCode.toUpperCase()];
	if (!country) country = DefaultCountryType;

  // Applying the changes...
  findObject(name + "_state_sel_mandatory").innerHTML = country.StateMandatory == 'YES' ? Mandatory : '&nbsp;';
  findObject(name + "_state_mandatory").innerHTML = country.StateMandatory == 'YES' ? Mandatory : '&nbsp;';
  findObject(name + "_state_sel_caption").innerHTML = country.StateName;
  findObject(name + "_state_caption").innerHTML = country.StateName;
  findObject(name + "_postcode_mandatory").innerHTML = country.ZipCodeMandatory == 'YES' ? Mandatory : '&nbsp;';
  findObject(name + "_postcode_caption").innerHTML = country.ZipCodeLabel;

  // ...including dispatching the custom event
	fireEvent(null, 'DateSequenceChange', [name, country.DateOrder]);
}

// Reacts on state selection box changes
function StateSelectionChange(name)
{
  var cc = GetCountryCode(name);

	// If the user selected "Other", show the state input box; clear the box on user action
	var states = findObject(name + "_state_sel"),
			State = states.options.selectedIndex != -1 ? states.options[states.options.selectedIndex].value : -2,
			NoStates = !DefaultHasStates || (states.options.length > 0 && states.options[2].value.toUpperCase() == 'DEFAULT'),
			StateUnknown = states.options.length == 0;
	showElements(name + "_state_row", (State < 0 && !NoStates) || StateUnknown);
	PrefixCaption(findObject(name + "_state_caption"), Places[cc] ? Places[cc].StateName : DefaultCountryType.StateName, (State == -1));

  // Fill in cities and react to selection change
  if (haveCity) {
  	FillSelectionItems(findObject(name + "_city_sel"), CityFillFunc, cc, GetStateIndex(cc, State), name + "_city_sel_row", name + "_city_row", findObject(name + "_city"));
    CitySelectionChange(name);
  }
}

// Reacts on country selection box changes
function CountrySelectionChange(name)
{
	var cc = GetCountryCode(name);

	// If the user selected "Other", show the country input box; clear the box on user action
	// Not necessary if country selection is suppressed
	if (!NoCountrySelection) {
	  var countries = findObject(name + "_country");
	  showElements(name + "_country_row", (cc == "XXX"));
	  PrefixCaption(findObject(name + "_country_caption"), CountryCaption, (cc == "XXX"));
	  if (!Initial) countries.value = "";
	}

	// Fill in the states
	FillSelectionItems(findObject(name + "_state_sel"), StateFillFunc, cc, 0, name + "_state_sel_row", name + "_state_row", findObject(name + "_state"));

	// Selection of state now has changed
	StateSelectionChange(name);

  // Change UI in response to changed country
  CountryOptions(cc, name);
}

// Reacts on city selection box changes
function CitySelectionChange(name)
{
  // If the user selected "Other", show the city input box; clear the box on user action
	var cities = findObject(name + "_city_sel"),
			City = cities.options.selectedIndex != -1 ? cities.options[cities.options.selectedIndex].value : -2;
  showElements(name + "_city_row", (City < 0));
  PrefixCaption(findObject(name + "_city_caption"), CityCaption, (City == -1));
  if (!Initial) findObject(name + "_city").value = "";
}

// Initialise the address controls
function InitPlaces(name, initialCountryCode)
{
	Initial = true;

	// Add general event handlers
  addEventHandler(findObject(name + "_state_sel"), "change", function() { StateSelectionChange(name); });
  if (haveCity) addEventHandler(findObject(name + "_city_sel"), "change", function() { CitySelectionChange(name); });
  
  if (NoCountrySelection) {
  
    // If country selection is disabled, the country field is not shown and the country code to use for the other
    // fields is being pre-selected
    CountrySelectionChange(name);

  } else {

    // Show the country selection if that is enabled; if JavaScript is disabled, just a country input field is being shown,
    // and no selection facilities will be available; set up event handlers and call the initial events to cause a cascade
    // of event handlers which will initialise the selection fields.
    selectByValue(findObject(name + "_country_sel"), initialCountryCode);
    showElements(name + "_country_sel_row", true);
    addEventHandler(findObject(name + "_country_sel"), "change", function() { CountrySelectionChange(name); });
    fireEvent(findObject(name + "_country_sel"), "change");
  }
  Initial = false;
}

// Publish the country change custom event
publishEvent("DateSequenceChange");


// Some notes:
// Elements that are hidden when selecting countries, states, etc. include not only the table row containing the
// input field (which would make the input field invisible all right), but also the input field itself. This helps
// to maintain focus issues in IE up to 7 which focusses the input elements as they are not hidden themselves.