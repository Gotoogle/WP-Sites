addEventHandler(null, "domready", function() {

// Scrolls an element within its closest scrollable ancestor within view
/*function scrollTo(o) {
  var parent = o;
	while (parent) do {
		if (getCSSValue(o, "overflow") == "auto" || getCSSValue(o, "overflow-x") == "auto" || getCSSValue(o, "overflow-y") == "auto") break;
		parent = parent.parentNode;
	}
	if (!parent) return;
	
} */

// -- Option Tabs -----------------------------------------------------------------------------------------------------

	// Shows the given tab as selected
	function selectTab(id)
	{
		if (!id) return;
		var filterFrame = findObject("filter-frame"), tabs = arrayCombine(getElementsByClass(filterFrame, "ACOptionTab"), getElementsByClass(filterFrame, "ACOptionTabSelected"));
    for (var i = 0, len = tabs.length; i < len; i++)
			if (tabs[i].id == id) tabs[i].className = "ACOptionTabSelected"; else tabs[i].className = "ACOptionTab";
	}
	
	// Issues the request to get an updated calendar image
	function updateCalendar(optionSet, errorUrl)
	{
		optionSet = optionSet || "";
		try {
			requestAsynchronous(ActiveCal.optionsetChangedScriptURL,
		                      {
														postData : { "OptionSet" : optionSet },
														origUrl : errorUrl,
														onAbort : function() { ActiveCal.showCover(false); },
														onSend : function() { ActiveCal.showCover(); },
			 										  onError : function() { window.location.href = this.origUrl; },
			 										  onTimeout : function() { window.location.ref = this.origUrl; },
			 										  onSuccess : function(status, response) {
                                          try {
																			      ActiveCal.showCover(false);
																						if (response != "") ActiveCal.viewFrame.innerHTML = response; else throw new Error("No Response. Reloading...");
																					} catch(e) {
																					  findObject("ActivityCalendar").innerHTML = e.message;
																						window.location.href = this.origUrl;
																					}
																				}
											    }, "tabs");
			selectTab(optionSet);
		} catch(e) { alert(e.message); return true; }
	}

	// Install event handlers to all tabs that do not activate the link, but request a new dataset via Ajax
  var filterFrame = findObject("filter-frame"), tabs = arrayCombine(getElementsByClass(filterFrame, "ACOptionTab"), getElementsByClass(filterFrame, "ACOptionTabSelected"));
  for (var i = 0, len = tabs.length; i < len; i++) {
		if (tabs[i].id != "") addEventHandler(tabs[i], "click", function(event) {
											if (event.target.className != "ACOptionTabSelected") updateCalendar(event.target.id, event.target.href);
											return false;
									  });
  }
  

// -- Main calendar update implementation -----------------------------------------------------------------------------

addEventHandler(null, "MainCalendarUpdate", function() { updateCalendar("", ActiveCal.calendarRefreshURL); });


// -- Floating Shopping Cart display ----------------------------------------------------------------------------------

var ShoppingCart = (function() {

	var _parts = { stateObj : null, anchor : null, button : null, buttonEmpty : null,
								 openLink : null, openLinkEmpty : null, body : null, scroller : null, content : null,
								 editLink : null, buttonEditLink : null, countSummary : null, totalSummary : null },  				// References to HTML part objects
			_currentButton = null,                                                                                  // Currently visible button
			_flashingItem = null,
      _slider = new AnimController({ duration: 250,
																		 transition: Animator.transitions.easeOut,
																		 onComplete: function() { if (this.target == 0) disappear(_parts.body); else {
																		               disappear(_currentButton);
																									 _flashItem(_flashingItem);
																									 _flashingItem = null;
																									} } }),
			_flash = new AnimController({ duration: 1500,
																		transition: Animator.transitions.easeIn }),
			_closedByUser = false,                                                                                  // Cart has been closed by user once
			_testObj = document.createElement("div");                                                               // Test object to read CSS class rules
			

	// Draws attention to the given element by starting the flashing animation and scrolling into view
	function _flashItem(o) {
		if (o) {
			//if (o.scrollIntoView) o.scrollIntoView(false);
			_flash.addClassTransition(o, "ACShoppingCartMarked", o.className, "-flash-", _testObj);
			_flash.play(0, 1);
			Anim.start();
		}
	}

	// Opens or closes the shopping cart; sets the animation going, or opens/closes the cart directly.
	function _show(doShow, animate, force) {
    var newState = (doShow != false) ? "1" : "0";
	  if (newState != _parts.stateObj.value || force) {
		  _parts.stateObj.value = newState;
		  _slider.playTo(newState);
      if (animate) Anim.start(); else _slider.setState(newState);
		  if (doShow != false) appear(_parts.body); else appear(_currentButton);
		}
	}
	
	// Adjusts the shopping cart's dimensions and adjusts the animation parameters
	function _recalcDimensions() {
    var savedHeight = _parts.body.style.height, savedWidth = _parts.body.style.width;

		_parts.scroller.style.height = "";                                // This resizes the elements to their natural sizes,
    _parts.scroller.style.width = "";                                 // depending on their content
		_parts.body.style.height = "";
		_parts.body.style.width = "";

		var buttonDim = getDimensions(_currentButton),
		    cartDim = getDimensions(_parts.body), scrollerDim = getDimensions(_parts.scroller), diff = [cartDim[0] - scrollerDim[0], cartDim[1] - scrollerDim[1]],
				fullDim = getDimensions(_parts.body, "margin"), availableHeight = document.body.clientHeight / 3 * 2,
				newHeight = fullDim[1] > availableHeight ? availableHeight - (fullDim[1] - cartDim[1]) : cartDim[1], scroller = [];
		cartDim[1] = newHeight < 50 ? 50 : newHeight;
		scroller = [cartDim[0] - diff[0], cartDim[1] - diff[1]];
		if (scroller[0] < 0) scroller[0] = 0;
		if (scroller[1] < 0) scroller[1] = 0;
		if (scroller[0] != scrollerDim[0] || scroller[1] != scrollerDim[1]) {
			scrollerDim = [scroller[0], scroller[1]];
		  scrollerDim = IESize(_parts.scroller, scrollerDim);
		  _parts.scroller.style.width = scrollerDim[0];
		  _parts.scroller.style.height = scrollerDim[1];
		}
		cartDim = IESize(_parts.body, cartDim);
		_slider.add(new AnimPropertyInteger(_parts.body, "width", buttonDim[0], cartDim[0]), "-width-");
    _slider.add(new AnimPropertyInteger(_parts.body, "height", buttonDim[1], cartDim[1]), "-height-");
    resizeTo(_parts.body, cartDim[0], cartDim[1]);                                                // Required by IE
    
    if (Anim.isRunning("ShoppingSlider") || _parts.stateObj.value != "1") {
			_parts.body.style.height = savedHeight;
		  _parts.body.style.width = savedWidth;
		}
	}
	
	// Sets the current button - changing between the version for an empty cart, and the one for a filled one
	function _setCurrentButton(emptyMode, force)
	{
		var prevButton = emptyMode ? _parts.button : _parts.buttonEmpty;
    _currentButton = emptyMode ? _parts.buttonEmpty : _parts.button;
		if ((!Anim.isRunning("ShoppingSlider") && _parts.stateObj.value !== "1") || force) {
			disappear(prevButton);
			appear(_currentButton);
		}
	}
	
	// Updates the shopping cart with a number of different data points, such as content, visibility of supplementary items, etc.
	function _updateContent(bodyContent, emptyMode, itemCountSummary, totalSummary) {
		_parts.content.innerHTML = bodyContent;
		showObject(_parts.editLink, !emptyMode);
		showObject(_parts.buttonEditLink, !emptyMode);
		_parts.countSummary.innerHTML = itemCountSummary;
		_parts.totalSummary.innerHTML = totalSummary;
		_setCurrentButton(emptyMode);
		_recalcDimensions();
	}
	
	// Prepares to animate the "New Item" flash in the cart, or on the closed cart button
	function _scheduleFlash(o) {
		if (!o) return;
		var cartClosed = _parts.stateObj.value !== "1";
		if (Anim.isRunning("ShoppingSlider")) {
			if (cartClosed) _flashItem(_currentButton); else _flashingItem = o;
		} else _flashItem(cartClosed ? _currentButton : o);
	}
	
	// Reacts on the click of one of the open links
	function _openLinkClick(e) {
		_show(_parts.stateObj.value != "1", true);
		e.stopPropagation();
		return false;
	}
	
	// Submits the current form the given URL
	function _formSubmit(url) {
		if (url) document.forms[0].action = url;
		document.forms[0].submit();
	}

	// Initialise
	for (var i in _parts) _parts[i] = findObject("shopping-cart-" + i.toCSSCase());
	_slider.add(new AnimPropertyInteger(_parts.body, "opacity", 0.2, 1.0, "-opacity-"));
	Anim.add(_slider, "ShoppingSlider");
	Anim.add(_flash, "ShoppingFlash");

	// The test object for CSS rules read-out; note, for IE not to break the entire page layout, this object must be put in the Shopping Cart
	// Anchor area. I have no idea why, and since I have to use quirksmode, I don't care. Consequently, I cannot use the automatic test object
	// feature built into the animation library.
	_testObj.style.display = "none";
	_parts.anchor.appendChild(_testObj);

	addEventHandler(_parts.openLink, "click", _openLinkClick);
	addEventHandler(_parts.openLinkEmpty, "click", _openLinkClick);
	addEventHandler(_parts.body, "click", function(e) {
																											if (e.target.id === "shopping-cart-edit-link") _formSubmit(e.target.href);
																											else {
																												_show(_parts.stateObj.value != "1", true);
																											  _closedByUser = true;
																											}
																											e.stopPropagation();
																											return false;
																										});
	addEventHandler(_parts.buttonEditLink, "click", function(e) {
																																_formSubmit(e.target.href);
																																e.stopPropagation();
																																return false;
																															});
	if (!isIE) addEventHandler(window, "resize", function() { _recalcDimensions(); });

	appear(_parts.anchor);
	_setCurrentButton(shoppingCartEmptyMode, true);
	showObject(_parts.editLink, !shoppingCartEmptyMode);
	showObject(_parts.buttonEditLink, !shoppingCartEmptyMode);
	_recalcDimensions();
  _show(_parts.stateObj.value == "1", false, true);
			
	// Create public interface
	return {
		// Shows the cart
		show : function(doShow, animate) { _show(doShow, animate); },

		// Updates the cart's display with a number of new content
		update : function(b, e, i, t, autoOpen, flashItem) {
		  _updateContent(b, e, i, t);
		  if (autoOpen && !_closedByUser) _show(true, true);
		  if (flashItem) _scheduleFlash(findObject("ACShoppingCartMarkedItem"));
		}
	};

})();


// -- Pop-up divs -------------------------------------------------------------------------------------------------------------------

var Popups = (function() {
	var _defaultSettings = { obj : null, placement : [0, 0], align: "", anchor: null },
			_list = {};

	// Calculates final position of popup
	function _position(popup) {
	
		// Stores the calculation algorithms
		var _positionHelpers = { primary   : { top    : function(anchorPos, anchorDim, objDim) { return anchorPos - objDim; },
																					 bottom : function(anchorPos, anchorDim, objDim) { return anchorPos + anchorDim; },
																					 left   : function(anchorPos, anchorDim, objDim) { return anchorPos - objDim; },
																					 right  : function(anchorPos, anchorDim, objDim) { return anchorPos + anchorDim; } },
														 secondary : { top    : function(anchorPos, anchorDim, objDim) { return anchorPos; },
																					 bottom : function(anchorPos, anchorDim, objDim) { return anchorPos + anchorDim - objDim; },
																					 left   : function(anchorPos, anchorDim, objDim) { return anchorPos; },
                      										 right  : function(anchorPos, anchorDim, objDim) { return anchorPos + anchorDim - objDim; } } },
				_opposite = { left : "right", right : "left", top : "bottom", bottom : "top" };

		// Calculates one ordinate of a popup position, depending on the values and options handed in, also checking against viewport limits
		function _calculatePosition(anchorPos, anchorDim, objDim, placement, docPos, windowDim, align, aOptions, algoBranch)
		{
			var temp = _positionHelpers[algoBranch][align](anchorPos, anchorDim, objDim) + placement, temp2;
			if ((temp - docPos < 0 && align == aOptions[1]) || (temp - docPos + objDim > windowDim && align == aOptions[0]))
				temp2 = _positionHelpers[algoBranch][_opposite[align]](anchorPos, anchorDim, objDim) + placement;
			return (temp2 && temp2 - docPos >= 0 && temp2 - docPos + objDim <= windowDim) ? temp2 : temp;
		}

		// Unanchored popups just appear at their dedicated positions
		if (!popup.align || !popup.anchor) moveTo(popup.obj, popup.placement[0], popup.placement[1])

		// Anchored popups appear next their anchor element
		else {
			var anchorPos = getAbsPos(popup.anchor), anchorDim = getDimensions(popup.anchor, "border"),
					objDim = getDimensions(popup.obj, "border"), windowDim = [document.body.clientWidth, document.body.clientHeight],
					docPos = [document.body.scrollLeft, document.body.scrollTop], align = popup.align.split("-"), objPos = [];

			if (align[0].match(/top|bottom/)) {
				objPos[1] = _calculatePosition(anchorPos[1], anchorDim[1], objDim[1], popup.placement[1], docPos[1], windowDim[1], align[0], ["bottom", "top"], "primary");
				if (align[1].match(/left|right/))
					objPos[0] = _calculatePosition(anchorPos[0], anchorDim[0], objDim[0], popup.placement[0], docPos[0], windowDim[0], align[1], ["left", "right"], "secondary");
			} else if (align[0].match(/left|right/)) {
        objPos[0] = _calculatePosition(anchorPos[0], anchorDim[0], objDim[0], popup.placement[0], docPos[0], windowDim[0], align[0], ["left", "right"], "primary");
        if (align[1].match(/top|bottom/))
          objPos[1] = _calculatePosition(anchorPos[1], anchorDim[1], objDim[1], popup.placement[1], docPos[1], windowDim[1], align[1], ["bottom", "top"], "secondary");
			}
			moveTo(popup.obj, objPos[0], objPos[1]);
		}
	}
	
	// Hides a popup
	function _hide(i) {
  	var popup = _list[i];
		if (popup) {
			if (popup.anchor && popup.activeClass) popup.anchor.className = removeTrait(popup.anchor.className, popup.activeClass);
			if (popup.controller) {
				Anim.add(popup.controller, "Anim" + i);
				popup.controller.playTo(0);
				Anim.start();
			} else {
			  disappear(popup.obj);
			  popup.obj.style.left = 0;
			  popup.obj.style.top = 0;
			}
		}
	}
	
	// Public interface
	return {
					 // Adds a HTML element to the Popups manager
					 add : function(o, tag, settings) {
						 if (!o || !tag) return;
						 settings = settings || {};
						 settings.obj = o;
						 if (settings.animation && !isIE) {
							 settings.controller = new AnimController({ duration: 500, transition: Animator.transitions.easeOut,
							 																						onComplete: function() { if (this.target == 0) {
																													                           disappear(settings.obj);
																																										 settings.obj.style.left = 0;
			  																																						 settings.obj.style.top = 0;
																																									 }
																																								 } });
							 settings.controller.add(new AnimPropertyInteger(settings.obj, "opacity", 0, 1));
							 settings.obj.style.opacity = 0;
						 }
						 addEventHandler(o, "click", function(e) { e.stopPropagation(); }, "-popup-base-");
						 _list[tag] = merge(_defaultSettings, settings);
					 },

					 // Shows a popup
					 show : function(tag, func) {
						 var popup = _list[tag];
						 if (popup) {
						   _position(popup);
						   if (popup.anchor && popup.activeClass) popup.anchor.className = addTrait(popup.anchor.className, popup.activeClass);
						   if (func) func(popup);
						   appear(popup.obj);
						   if (popup.controller) {
								 Anim.add(popup.controller, "Anim" + tag);
								 popup.controller.playTo(1);
								 Anim.start();
						   }
						 }
		       },
		       
		       // Hides a popup
		       hide : function(tag) {
						 if (!tag) { for (var i in _list) { _hide(i); } }
						 else _hide(tag);
		       }
		     };
})();


// -- Event/Product selection and processing ----------------------------------------------------------------------------------------

	var loading = false;                                          // Indicates whether event/product data is being loaded

	// Shows a product-related popup
	function productPopup(anchor, popupID, content, fadeIn, tryAgain) {
		findObject(popupID + "-content").innerHTML = content;
		var tryAgainLink = findObject(popupID + "-try-again");
		showObject(tryAgainLink, !!tryAgain);
		if (tryAgain) tryAgainLink.href = tryAgain;
		Popups.add(findObject(popupID), popupID, { anchor : anchor,
																							 align : "bottom-left",
																							 activeClass : "ACEventSelected",
																							 animation : fadeIn
																					   });
		Popups.show(popupID);
		addEventHandler(findObject(popupID + "-close"), "click", function() { Popups.hide(); return false; }, popupID + "-close");
	}
	
	// Processes the response from the server - parses the XML response and decides what to make available on-screen
	function processResponse(status, response, productRequest) {

		try {
			// Exception thrown during server-side script
			if (response.match(/^Error:|Compiler Error:/)) {
				Popups.hide();
				productPopup(this.anchor, "product-error", response, false, this.origUrl);
			}

		  // Parse response into XML and act
		  else {
				var doc = parseXML(response), error = getNodeValue(doc, "/activity-calendar-user-selection/event-error"),
																			update = getNodeValue(doc, "/activity-calendar-user-selection/event-error-update"),
																			products = getNodeValue(doc, "/activity-calendar-user-selection/product-content"),
																			cart = getNodeValue(doc, "/activity-calendar-user-selection/cart-content"),
																			count = parseInt(getNodeValue(doc, "/activity-calendar-user-selection/cart-item-count"), 10),
																			countContent = getNodeValue(doc, "/activity-calendar-user-selection/cart-item-count-summary"),
																			totalContent = getNodeValue(doc, "/activity-calendar-user-selection/cart-total-summary");
				if (error) {
					Popups.hide();
					if (update.toLowerCase() === "yes") {
					  productPopup(this.anchor, "event-error", error);
				    addEventHandler(findObject("event-error-update"), "click", function() { Popups.hide(); fireEvent(null, "MainCalendarUpdate"); return false; }, "-calendar-update-");
				  } else productPopup(this.anchor, "product-error", error);
				} else {

					// Show a product selection pop up if required, or update the shopping cart
					if (products && !productRequest) {
						productPopup(this.anchor, "product-popup", products, true);
					  attachEventHandlers(findObject("product-popup-content"), this.anchor);
					} else if (cart) {
						if (!productRequest) this.anchor.className = removeTrait(this.anchor.className, "ACEventSelected");
						ShoppingCart.update(cart, (isNaN(count) || count < 1), countContent, totalContent, true, true);
					} else throw "Unexpected response from server";
				}
			}
		} catch(e) { Popups.hide(); productPopup(this.anchor, "product-error", e.message || e, false, this.origUrl); } finally { Popups.hide("event-wait"); }
	}
	
	// Injects or takes away a little HTML showing a waiting animation
	function buttonWait(button, doShow)
	{
		var dim = getDimensions(button);
		showObject(button, !doShow);
		if (doShow) {
			if (!buttonWait.div) {
			  buttonWait.div = document.createElement("div");
			  buttonWait.div.id = "button-wait";
			  buttonWait.div.className = "ButtonWait";
			}
			button.parentNode.insertBefore(buttonWait.div, button);
			dim = IESize(buttonWait.div, dim);
			resizeTo(buttonWait.div, dim[0], dim[1]);
		} else button.parentNode.removeChild(buttonWait.div);
	}
	buttonWait.div = null;
	
	// Attaches/processes event handlers for the buttons on a products popup
	function attachEventHandlers(contentObj, origAnchor)
	{
		if (!contentObj) return;
		addEventHandler(contentObj, "click", function(e) {
			id = e.target.id.split("-");
			try {

				// Request to put a product into the cart
				if (id[0] == "toCart") {

	        requestAsynchronous(ActiveCal.userSelectionScriptURL,
															{
		                            postData : { "EventID" : id[1], "ProductID" : id[2] },
		                            anchor: origAnchor,
		                            target: e.target,
		                            onSend : function() { buttonWait(this.target, true); },
																onError : function() { Popups.hide(); buttonWait(this.target, false); productPopup(this.anchor, "product-error", "Error during request", false); },
					 										  onTimeout : function() { Popups.hide(); buttonWait(this.target, false); productPopup(this.anchor, "product-error", "The request timed out.", false); },
					 										  onAbort : function() { buttonWait(this.target, false); },
					 										  onComplete : function() { buttonWait(this.target, false); },
					 										  onSuccess : function(status, response) { processResponse.call(this, status, response, true); }
															}, "eventsNproducts");
					return false;


				// Request to show more information about a product
				} else if (id[0] == "info") { }
			} catch(e) { Popups.hide(); productPopup(origAnchor, "event-error", e.message || e); }
		}, "-popup-content-handler-");
	}

	// Add an event handler to handle all event/product links on the page
	addEventHandler(findObject("ActivityCalendar"), "click", function(e) {

		// Event items (user selects a link representing an event in the calendar)
		var target = e.target;
		do { if (target.nodeName.toLowerCase() === "a") break; } while (target = target.parentNode);
		if (target && hasTrait(target.className, "ACEventItem")) try {
			requestAsynchronous(ActiveCal.userSelectionScriptURL,
													{
                            postData : { "EventID" : target.id.split("-")[1] },
                            anchor: target,
														origUrl : target.href,
														onSend : function() {
																									Popups.hide();
																									this.anchor.className = addTrait(this.anchor.className, "ACEventSelected");
																									Popups.add(findObject("event-waiting"), "event-wait", { anchor : this.anchor, align : "right-top" });
																									Popups.show("event-wait", function (popup) { resizeTo(popup.obj, 20, getHeight(popup.anchor)); });
																									loading = true; },
														onError : function() { window.location.href = this.origUrl; },
			 										  onTimeout : function() { window.location.ref = this.origUrl; },
														onComplete: function() { loading = false; },
														onAbort : function() { this.anchor.className = removeTrait(this.anchor.className, "ACEventSelected");
														                       loading = false; },
			 										  onSuccess : function(status, response) { processResponse.call(this, status, response, false); }
													}, "eventsNproducts");
			return false;
		} catch(e) { /* continue with default action, i. e. follow the link */ }

	});
	
	addEventHandler(document, "click", function() { if (!loading) Popups.hide(); });

});
