// Helper functions --

var timerHelper = 0;
// Runs a function after certain delay; if the function is called again, the first one will be cancelled
// as long as the delay has not finished.
function delay(src)
{
	window.clearTimeout(timerHelper);
	timerHelper = window.setTimeout(src, 50);
}


// Support functions for popup calendar --

// Hides the calendar
function hideCalendar()
{
	if (calendar) calendar.hide();
}

// Reacts on a date selection
function selectDate(d, m, y)
{
	findObject("StartDay").value = d;
	findObject("StartMonth").value = m;
	findObject("StartYear").value = y;
	findObject("calendar1_month").value = m;
	findObject("calendar1_year").value = y;
	findObject("ChangeDate").value = "DoIt";
	document.forms[0].submit();
	return false;
}

// Gets the current selection for the calendar
function getStartDate() {
	return new Date(findObject("StartYear").value, findObject("StartMonth").value - 1, findObject("StartDay").value);
}


// Event handling for three main calendars --

// Reacts on the selection of a date in one of the calendars
function selectTour(d, m, y)
{
	// Reflect change on calendars, set date in page state
	calendar1.setCurrentDate(new Date(y, m - 1, d));
	calendar2.setCurrentDate(new Date(y, m - 1, d));
	calendar3.setCurrentDate(new Date(y, m - 1, d));
	findObject("StartDay").value = d;
	findObject("StartMonth").value = m;
	findObject("StartYear").value = y;

	// Update the products and tours section of the page or the attributes section of the pages
	dateChangeFunction(true, d, m, y);

	// Override natural link behaviour
	return false;
}

// Updates the calendars display starting on given month
function updateCalendarsDisplay(month, year)
{
  // The following only works because the calendars display never spans a year boundary.
	var startMonth = month, endMonth, startYear = year, endYear, a;
	calendar1.fillCalendar(month, year);
	a = incMonth(month, year, 1);
	month = a[0]; year = a[1];
	calendar2.fillCalendar(month, year);
	a = incMonth(month, year, 1);
	month = a[0]; year = a[1];
	calendar3.fillCalendar(month, year);
	endMonth = month;
	endYear = year;

	// Construct a new title
	findObject("ScheduleDateTitle").innerHTML = MonthNames[startMonth - 1] + " " + (startYear != endYear ? startYear + " " : "") + "- " + MonthNames[endMonth - 1] + " " + endYear;
}

// Increase or decrease the month
function incMonth(m, y, increment)
{
	var tmp;
	if (increment == 0) return [m, y];
	else if (increment < 0) {
    tmp = m + increment;
		if (tmp < 1) {
			if (tmp < 0) tmp = -tmp;
			return [-(tmp - (Math.floor(tmp / 12) + 1) * 12), y - (Math.floor(tmp / 12) + 1)];
		} else return [tmp, y];
	} else {
    tmp = m + increment;
		if (tmp > 12) return [tmp - Math.floor(tmp / 12) * 12, y + Math.floor(tmp / 12)];
		else return [tmp, y];
	}
}

// Go three months back or forth
function browseCalendars(back)
{
	// Current start of view is stored in the hidden input fields of the first calendar
	var currentMonth = parseInt(calendar1.currentMonth), currentYear = parseInt(calendar1.currentYear);
	var amount = (back ? -3 : 3);
	var a = incMonth(currentMonth, currentYear, amount);
	currentMonth = a[0];                                          // shorter: [currentMonth, currentYear] = incMonth(currentMonth, currentYear, amount);
	currentYear = a[1];                                           // but not recognised by IE

	// Update all the calenders - no cell will be available
	updateCalendarsDisplay(currentMonth, currentYear);

	// Ask the server on what dates still tours are going and are not sold out
	var startTime, endTime;
	startTime = currentYear + leadingZero(currentMonth) + "01";
	a = incMonth(currentMonth, currentYear, 3);
	currentMonth = a[0];                                          // see above
	currentYear = a[1];
	endTime = currentYear + leadingZero(currentMonth) + "01";
	SequenceNumberAvailableDates++;
	alert("Not yet re-implemented with new Ajax functions!");
	if (!requestAsynchronous("GET", GetAvailableDatesScript + "?Seq=" + SequenceNumberAvailableDates + "?StartDate=" + startTime + "?EndDate=" + endTime + ":" + SessionID, updateCalendars, ""))
	  document.forms[0].submit();
}

// Called when the request to the server is being performed. Has the
// response successfully arrived, the calendars are updated the availability information
function updateCalendars(requestObject)
{
	try {

		// Do nothing until we get called for the download complete signal
		if (requestObject.readyState != 4) return;

		// Submit the page if the HTTP status code indicates failure
		if (requestObject.status != 200) {
			document.forms[0].submit();
			return;
		}
		
		var dates = requestObject.responseText.split(","), i, j;
		var sequenceNumber = dates[0];
		if (parseInt(sequenceNumber) != SequenceNumberAvailableDates) return;
		dates.splice(0, 1);
		calendar1.enumCells(makeCellAvailable, dates);
		calendar2.enumCells(makeCellAvailable, dates);
		calendar3.enumCells(makeCellAvailable, dates);
	} catch(e) {
	}
}

// Makes a cell available if its date is in the given array of dates
function makeCellAvailable(cell, idx, dates)
{
	var dateString = cell.date.getFullYear() + leadingZero(cell.date.getMonth() + 1) + leadingZero(cell.date.getDate());
	if (dates.indexOf(dateString) != -1) cell.calendar.changeAvailability(idx, true);
}

// Initiates a request to the server about what tours on a day are available.
function getAvailableProductsAndTours(productsUpdate, d, m, y)
{
  // Show the new start date in the 'Tour Times' section
	var date = new Date(y, m - 1, d), s = weekDays[date.getDay()] + ", " + d + " " + shortMonths[m - 1] + ", " + y;
	findObject("tour_date").innerHTML = s;

	findObject("available_tours").style.display = "none";
	findObject("waiting_message_tours").style.display = "";
	if (productsUpdate) {
		findObject("available_products").style.display = "none";
		findObject("waiting_message_products").style.display = "";
	}

	// This will execute the same scripts as on page entry which use session values heavily. So prepare
	// some post data for the scripts; start with the currently selected date
	var postData = "StartDay=" + leadingZero(findObject("StartDay").value) + "&StartMonth=" + leadingZero(findObject("StartMonth").value) + "&StartYear=" + findObject("StartYear").value;

	// Collect the ticket quantities
	var ticketControls = getAllElements("select"), i;
	for (i = 0; i < ticketControls.length; i++) {
		if (ticketControls[i].className == "quantity_control")
		  postData += "&" + ticketControls[i].name + "=" + ticketControls[i].options[ticketControls[i].selectedIndex].value;
	}

	// And the preference values
	if (findObject("daytime_morning").checked) postData += "&DayTime=morning";
	else if (findObject("daytime_afternoon").checked) postData += "&DayTime=afternoon";

	// Send the request
	SequenceNumberBottomPart++;
  alert("Not yet re-implemented with new Ajax functions!");
  if (!requestAsynchronous("POST", (productsUpdate ? GetAvailableProductsScript : GetAvailableTimeSlotsScript) + "?Seq=" + SequenceNumberBottomPart + ":" + SessionID, updateBottomPart, postData))
	  document.forms[0].submit();
}

// Called when the request to the server is being performed. Has the
// information successfully arrived, update the "Tour Times" section of the page
function updateBottomPart(requestObject)
{
	try {

		// Do nothing until we get called for the download complete signal
		if (requestObject.readyState != 4) return;

		// Submit the page if the HTTP status code indicates failure
		if (requestObject.status != 200) {
			document.forms[0].submit();
			return;
		}

		// The script sends back a sequence number which is used here to determine if the result is still being needed (not if already
		// a new asynchronous request has been started). Since the server could deliver two parts, one for the products section and one
		// for the tours section, each preceeded by a sequence number, the number is also used as a delimiter between the parts and as
		// a signal which section to update.
		var s = requestObject.responseText, seqNumber = /%%(\d*)%%/.exec(s), s2 = "";
		if (seqNumber && seqNumber[1]) {
			if (parseInt(seqNumber[1]) != SequenceNumberBottomPart) return;         // Wrong sequence number
			s = s.slice(seqNumber.index + seqNumber[0].length);

			// Now, check if there is a second part; this time the sequence number itself is of no interest anymore since it has been checked already
			seqNumber = /%%(\d*)%%/.exec(s);
			if (seqNumber) {
				s2 = s.slice(seqNumber.index + seqNumber[0].length);
				s = s.slice(0, seqNumber.index);
			}
		}

		if (s2 != "") {
			findObject("available_products").innerHTML = s;
			findObject("available_tours").innerHTML = s2;
			registerTicketControlEvents();
		} else findObject("available_tours").innerHTML = s;

		findObject("available_tours").style.display = "";
		findObject("waiting_message_tours").style.display = "none";
		findObject("available_products").style.display = "";
		findObject("waiting_message_products").style.display = "none";
	} catch(e) {
	}
}

// Initiates a request to the server about what attributes (events) are available at the selected time
function getAvailableAttributes(dummy, d, m, y)
{
  // Show the new start date in the events heading section
	var date = new Date(y, m - 1, d), s = weekDays[date.getDay()] + ", " + d + " " + shortMonths[m - 1] + ", " + y;
	findObject("event_date").innerHTML = s;

	findObject("available_attributes").style.display = "none";
	findObject("waiting_message_attributes").style.display = "";

	// This will execute the same scripts as on page entry which use session values heavily. So prepare
	// some post data for the scripts; start with the currently selected date
	var postData = "StartDay=" + leadingZero(findObject("StartDay").value) + "&StartMonth=" + leadingZero(findObject("StartMonth").value) + "&StartYear=" + findObject("StartYear").value;

	// Send the request
	SequenceNumberBottomPart++;
	alert("Not yet re-implemented with new Ajax functions!");
  if (!requestAsynchronous("POST", GetAvailableAttributesScript + "?Seq=" + SequenceNumberBottomPart + ":" + SessionID, updateAttributes, postData))
	  document.forms[0].submit();
}

// Called when the request to the server is being performed. When the
// information has arrived, update the list of attributes
function updateAttributes(requestObject)
{
	try {

		// Do nothing until we get called for the download complete signal
		if (requestObject.readyState != 4) return;

		// Submit the page if the HTTP status code indicates failure
		if (requestObject.status != 200) {
			document.forms[0].submit();
			return;
		}

		// The script sends back a sequence number which is used here to determine if the result is still being needed (not if already
		// a new asynchronous request has been started). The update is only shown, if the result comes not out of sequence.
		var s = requestObject.responseText, seqNumber = /%%(\d*)%%/.exec(s);
		if (seqNumber && seqNumber[1]) {
			if (parseInt(seqNumber[1]) != SequenceNumberBottomPart) return;         // Wrong sequence number
			s = s.slice(seqNumber[0].length);
		}
	  findObject("available_attributes").innerHTML = s;
		findObject("available_attributes").style.display = "";
		findObject("waiting_message_attributes").style.display = "none";
	} catch(e) {
	}
}


// Other page interactivity --

// Reacts on the change of a ticket quantity selection box
function quantityChanged(o)
{
	// Update the display of the prices
	var ticketControls = getAllElements("select"), i, idxStr, price = 0.0, total = 0.0, grandTotal = 0.0;
	for (i = 0; i < ticketControls.length; i++) {
		if (ticketControls[i].className == "quantity_control") {
			idxStr = ticketControls[i].id.substring("quantity".length);
			price = findObject("price" + idxStr).innerHTML;
			total = parseFloat(price.substring(currencySymbol.length)) * parseInt(ticketControls[i].options[ticketControls[i].options.selectedIndex].value);
			grandTotal += total;
			findObject("total" + idxStr).innerHTML = currencySymbol + formatFloat(total, 2);
		}
	}
	findObject("grand_total").innerHTML = currencySymbol + formatFloat(grandTotal, 2);

	// Recalculate the available tours section
	delay("getAvailableProductsAndTours(false, findObject('StartDay').value, findObject('StartMonth').value, findObject('StartYear').value);");

	return false;
}

// Registers the event handlers for the ticket controls
function registerTicketControlEvents()
{
  var ticketControls = getAllElements("select"), i;
	for (i = 0; i < ticketControls.length; i++) {
		if (ticketControls[i].className == "quantity_control") addEventHandler(ticketControls[i], "change", quantityChanged);
	}
}