// Auxiliary functions and event handlers for HTML select based multi-lists
// Include this file in a page, when a MultiList with suitable templates is used on it

function MultiList(levels, showlevels, advancemode) {                                         // Defines a MultiList
	this.levels = levels;
	this.showlevels = showlevels;
	this.advancemode = advancemode;
}

// Registers all MultiLists on a page
var MultiLists = {};

// Finds the item with the specified id
function findItem(level, id)
{
	var found;
	for (var i = 0; i < level.length; i++) {
		if (level[i].id == id) return level[i];
		found = findItem(level[i].nextlevel, id);
		if (found) return found;
	}
  return null;
}

// Selects the items in the parent lists in case 'NO-SELECT' is set and there are parent lists
// with no selection
function selectParentLists(parentid, level, prefix)
{
  var piArray = parentid.split('-'), i, listObj;
  for (i = piArray.length; i > 0; i--, level--) {
    listObj = findObject("MultiList" + prefix + "Level" + level);
    if (listObj && listObj.selectedIndex == -1) selectByValue(listObj, piArray.slice(0, i).join('-'));
  }
  return true;
}

// Retrieves the list at the next level
function getNextLevelListObject(thisLevel)
{
	var mlArray = MultiLists.split(','), i;
	for (i = 0; i < mlArray.length - 1; i++)
		if (thisLevel == mlArray[i]) return findObject("MultiList" + MultiListControlPrefix + "Level" + mlArray[i + 1]);
	return null;
}

// Retrieves the next list in the hierarchy, clears it, and fills it with new content according
// to the selection in the given list
function handleNextList(thisList, mlArray, prefix)
{
  // If the last list is to be handled, just call its handler
	if (mlArray.length < 1) return fireEvent(thisList, "change");

  // Otherwise clear the list, retrieve the selection from this list and refill it with new content
	var nextList = findObject("MultiList" + prefix + "Level" + mlArray[0]), level, i, parentid = "";
	if (!nextList) return true;
	nextList.options.length = 0;
	if (thisList.selectedIndex != -1) parentid = thisList.options[thisList.selectedIndex].value;
	else if (MultiLists[prefix].advancemode.toUpperCase() == "NO-SELECT" && thisList.options.length > 0) parentid = thisList.options[0].value;
	if (parentid != "" && (level = findItem(MultiLists[prefix].levels, parentid))) {
		for (i = 0; i < level.nextlevel.length; i++) nextList.options[nextList.options.length] = new Option(level.nextlevel[i].Name, level.nextlevel[i].id);
		if (MultiLists[prefix].advancemode.toUpperCase() == "SELECT" && nextList.options.length > 0) nextList.selectedIndex = 0;
	}
	return handleNextList(nextList, mlArray.slice(1), prefix);
}

// Handles the selection change in one of the lists of the multilist (except for the last one)
function handleList(list, prefix)
{
	var mlArray = MultiLists[prefix].showlevels.split(','), i, level;
	if (list.selectedIndex < 0) return true;
	if (!(level = findItem(MultiLists[prefix].levels, list.options[list.selectedIndex].value))) return true;
	for (i = 0; i < mlArray.length; i++) if (level.level == mlArray[i]) handleNextList(list, mlArray.slice(i + 1), prefix);
	selectParentLists(level.parentid, level.level - 1, prefix);

  return true;
}

// Handles the selection change in the last list
function handleLastList(list, prefix)
{
	var Text = "&nbsp;", level;  //, commentobj = findObject("MultiList" + prefix + "Comment");   				// No product description
	if (list.selectedIndex != -1) {
	  level = findItem(MultiLists[prefix].levels, list.options[list.selectedIndex].value);
	  if (level && level.Comment) Text = level.Comment;
	}
	//if (commentobj) commentobj.innerHTML = Text;                        											// No product description
	if (level) return selectParentLists(level.parentid, level.level - 1, prefix);
}


//function handleLastList(list, prefix)
//{
//	var Text = "&nbsp;", level, commentobj = findObject("MultiList" + prefix + "Comment");
//	if (!commentobj) return true;
//	if (list.selectedIndex != -1) {
//	  level = findItem(MultiLists[prefix].levels, list.options[list.selectedIndex].value);
//	  if (level && level.Comment) Text = level.Comment;
//	}
//	commentobj.innerHTML = Text;
//	if (level) return selectParentLists(level.parentid, level.level - 1, prefix);
//}


// Installs the event handlers for each select list within the control
// All lists except for the last one will have handlers that change the list content on the next list
// The last list updates an element with the id "MultiList" + <!ControlPrefix> + "Comment" to the comment
// of the currently selected item
// By the way, it also changes the page's current default button to the MultiList's "Add To Cart" button
function installListChangeHandlers(levels, prefix, showlevels, advancemode)
{
	// Register the new MultiList
	MultiLists[prefix] = new MultiList(levels, showlevels, advancemode);
	
	// Install the event handlers
	var mlArray = showlevels.split(','), i, name;
	for (i = 0; i < mlArray.length; i++) {
		name = "MultiList" + prefix + "Level" + mlArray[i];
		addEventHandler(findObject(name), "change", (i == mlArray.length - 1) ? function() { handleLastList(this, prefix); } : function() { handleList(this, prefix); } );
		addEventHandler(findObject(name), "focus", function() { defaultButton = findObject("addtocartbutton");	setCurrentDefaultButton(defaultButton); return true; } );
	}

  // Pre-select (just select the first category item and let the list handlers do the rest)
  var listObj;
  if (MultiLists[prefix].advancemode.toUpperCase() == "SELECT" && mlArray.length > 0) {
    listObj = findObject("MultiList" + prefix + "Level" + mlArray[0]);
    if (listObj && listObj.options.length > 0 && listObj.options.selectedIndex < 0) {
		  listObj.options.selectedIndex = 0;
			fireEvent(listObj, "change");
    }
    
		// Render comment (JavaScript only feature)
		//listObj = findObject("MultiList" + prefix + "Level" + mlArray[mlArray.length - 1]);
    //if (listObj) handleLastList(listObj, prefix);
  }
}
