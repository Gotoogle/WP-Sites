// ActivityCalendar.js
// -------------------

// Interactive part of the Activity Calendar. Pages wanting to interact with the calendar during page life time need to create an object
// instance first.

(function(window) {

window.ActivityCalendar = function(name, currentDateField) {
	this.viewFrame = findObject(name);
	this.dateField = findObject(currentDateField);
	this.currentDate = new Date();
	this.fullMonthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	this.shortMonthNames = [ "Jan", "Feb", "Mar", "Apr", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	this.coverRefCount = 0;

	// Internal cover element to be shown
	var _cover = {
	  create : function() {
		  if (!this.cover) {
				this.cover = window.document.createElement("div");
		    this.cover.id = name + "-busy-cover";
		    this.cover.className = "ACBusyCover";
		    this.cover.style.position = "absolute";
		    this.cover.style.visibility = "hidden";
		    document.body.appendChild(this.cover);
		  }
		},
		cover : null
	};
	
	// Sets a new date (is also called right away to initialise the date field)
	this.setDate = function(newDate) {
    if (newDate instanceof Date) this.currentDate = new Date(newDate.getFullYear(), newDate.getMonth(), newDate.getDate(), 12);
    else
			// Assume, it's a string and parse it to be YYYYMMDD
			this.currentDate = trunc(readDate(newDate, new Date()), 12);
	}
	this.setDate(this.dateField ? this.dateField.value : "");

	// Shows/hides a special cover element when the calendar is busy.
	this.showCover = function(doShow) {
		this.coverRefCount = (doShow === false ? this.coverRefCount - 1 : this.coverRefCount + 1);
		if (this.coverRefCount < 1) {
		  disappear(_cover.cover);
		  resizeTo(_cover.cover, 0, 0);
		} else {
			_cover.create();
			var x = getX(this.viewFrame), y = getY(this.viewFrame), dim = getDimensions(this.viewFrame, "border");
			IESize(_cover.cover, dim);
			resizeTo(_cover.cover, dim[0], dim[1]);
			moveTo(_cover.cover, x, y);
			appear(_cover.cover);
		}
	};
}

publishEvent("MainCalendarUpdate");

})(window);

